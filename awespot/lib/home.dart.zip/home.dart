import 'package:awespot/upload.dart';
import 'package:flutter/material.dart';
import 'package:multi_image_picker/multi_image_picker.dart';
import 'dart:async';

class HomePage extends StatefulWidget {

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<Asset> images = List<Asset>();
  String _error = 'No Error Dectected';



  @override
  Widget build(BuildContext context) {
    MediaQueryData query = MediaQuery.of(context);
    double width = query.size.width;
    double height = query.size.height;

    return new Scaffold(
      backgroundColor: Colors.black26,
      floatingActionButton: Container(
        width: width*0.3,
        height: height*0.12,
        child: new FloatingActionButton(
          elevation: 20.0,
          backgroundColor: HexColor("#ECAE00"),
          tooltip: 'Increment',
          child:  new Icon(Icons.add),
          onPressed: (){
            Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => UploadPage()));
          },
        ),
      ),
      bottomNavigationBar: BottomAppBar(
          elevation: 40.0,
          color: HexColor("#212121"),
          child: Container(
            width: width,
            height: height*0.1,
            child: new Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Expanded(
                    child: Column(
                      children: [
                        IconButton(
                          icon: Icon(
                            Icons.search,
                            color: Colors.white,
                          ),
                        ),
                        Text(
                          "검색",
                          style: TextStyle(
                            fontSize: height*0.015,
                            color: Colors.white,
                          ),
                        ),
                      ],
                    )
                ),
                Expanded(
                    child: new Text('')
                ),
                Expanded(
                  child: Column(
                    children: [
                      IconButton(
                        icon: Icon(
                          Icons.people_outline,
                          color: Colors.white,
                        ),
                      ),
                      Text(
                        "커뮤니티",
                        style: TextStyle(
                          fontSize: height*0.015,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          )
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
  }
}

class HexColor extends Color {
  static int _getColorFromHex(String hexColor) {
    hexColor = hexColor.toUpperCase().replaceAll("#", "");
    if (hexColor.length == 6) {
      hexColor = "FF" + hexColor;
    }
    return int.parse(hexColor, radix: 16);
  }

  HexColor(final String hexColor) : super(_getColorFromHex(hexColor));
}